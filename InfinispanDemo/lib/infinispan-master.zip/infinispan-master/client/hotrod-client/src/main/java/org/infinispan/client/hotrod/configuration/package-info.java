/**
 * Hot Rod client configuration API.
 *
 * @public
 */
package org.infinispan.client.hotrod.configuration;
