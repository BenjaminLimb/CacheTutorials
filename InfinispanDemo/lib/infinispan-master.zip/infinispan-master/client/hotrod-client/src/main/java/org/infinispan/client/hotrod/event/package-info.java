/**
 * Hot Rod client remote event API.
 *
 * @public
 */
package org.infinispan.client.hotrod.event;
