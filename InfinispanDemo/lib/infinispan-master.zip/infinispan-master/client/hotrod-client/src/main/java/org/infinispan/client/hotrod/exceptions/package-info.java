/**
 * Hot Rod client exceptions.
 *
 * @public
 */
package org.infinispan.client.hotrod.exceptions;
