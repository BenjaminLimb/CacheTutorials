package org.infinispan.client.hotrod;

/**
 * VersionedMetadata
 * @author Tristan Tarrant
 * @since 9.0
 */
public interface VersionedMetadata extends Versioned, Metadata {
}
