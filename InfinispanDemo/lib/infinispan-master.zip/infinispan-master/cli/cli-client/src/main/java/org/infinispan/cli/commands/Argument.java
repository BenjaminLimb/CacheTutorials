package org.infinispan.cli.commands;

public interface Argument {
   public String getValue();

   int getOffset();
}
