/**
 * This package contains the event bridge implementation between Infinispan and CDI.
 */
package org.infinispan.cdi.embedded.event;
