/**
 * This package contains the logging classes.
 */
package org.infinispan.cdi.embedded.util.logging;
