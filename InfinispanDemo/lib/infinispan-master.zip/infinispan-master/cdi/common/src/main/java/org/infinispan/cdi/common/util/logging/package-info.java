/**
 * This package contains the logging classes.
 */
package org.infinispan.cdi.common.util.logging;
