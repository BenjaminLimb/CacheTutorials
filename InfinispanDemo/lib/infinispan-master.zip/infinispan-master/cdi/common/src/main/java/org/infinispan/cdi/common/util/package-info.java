/**
 * This package contains utility classes.
 */
package org.infinispan.cdi.common.util;
